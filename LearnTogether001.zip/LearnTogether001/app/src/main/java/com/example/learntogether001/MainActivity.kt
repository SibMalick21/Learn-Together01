package com.example.learntogether001

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.learntogether001.ui.theme.LearnTogether001Theme
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LearnTogether001Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "$name",
        modifier = modifier
            .padding(vertical = 240.dp)
            .absolutePadding(left = 16.dp, right = 16.dp, top = 16.dp, bottom = 16.dp),
        textAlign = TextAlign.Justify
    )
}
@Composable
fun GreetingOne(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "$name",
        modifier = modifier
            .absolutePadding(left = 16.dp, right = 16.dp, top = 16.dp, bottom = 16.dp),
        fontSize = 24.sp,
        lineHeight = 259.sp,
    )
}
@Composable
fun GreetingSecond(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "$name",
        modifier = modifier
            .padding(vertical = 175.dp)
            .absolutePadding(left = 16.dp, right = 16.dp),
        textAlign = TextAlign.Justify,
    )
}

@Composable
fun GreetingImage(message: String, from: String, modifier: Modifier = Modifier) {
    val image = painterResource(R.drawable.bg_compose_background)
    Image(
        painter = image,
        modifier = modifier,
        contentDescription = null
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview(){
    GreetingImage("", from = "")
    GreetingOne("Jetpack Compose tutorial")
    GreetingSecond("Jetpack Compose is a modern toolkit for building native Android UI. Compose simplifies and accelerates UI development on Android with less code, powerful tools, and intuitive Kotlin APIs.")
    Greeting("In this tutorial, you build a simple UI component with declarative functions. You call Compose functions to say what elements you want and the Compose compiler does the rest. Compose is built around Composable functions. These functions let you define your app\\'s UI programmatically because they let you describe how it should look and provide data dependencies, rather than focus on the process of the UI\\'s construction, such as initializing an element and then attaching it to a parent. To create a Composable function, you add the @Composable annotation to the function name.")
}